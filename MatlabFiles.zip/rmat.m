function A = rmat(m,n)
A = fix(10*rand(m,n));
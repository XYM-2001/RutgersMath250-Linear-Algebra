function v = rvect(m) 
v = fix(10*rand(m,1));